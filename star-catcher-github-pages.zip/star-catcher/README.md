# Star Catcher — Hứng Sao

Game arcade 2D chạy trực tiếp trên trình duyệt, không cần thư viện hay máy chủ.

## Chơi game
- Máy tính: dùng `←` / `→` hoặc `A` / `D`.
- Điện thoại: dùng hai nút cảm ứng hoặc chạm/kéo trong khu vực chơi.
- Hứng sao vàng để nhận 10 điểm; né thiên thạch màu đỏ.
- Kỷ lục được lưu trên thiết bị bằng localStorage.

## Chạy thử
Mở `index.html` bằng trình duyệt.

## Đưa lên GitHub Pages
1. Tạo một repository mới, ví dụ `star-catcher`.
2. Tải `index.html` và `README.md` lên thư mục gốc của repository.
3. Mở **Settings → Pages**.
4. Trong **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch **main**, folder **/(root)**, rồi nhấn **Save**.
6. Chờ GitHub xuất bản trang. Đường dẫn thường có dạng `https://TEN-TAI-KHOAN.github.io/star-catcher/`.

Lưu ý: thay `TEN-TAI-KHOAN` bằng tên tài khoản GitHub của bạn.
